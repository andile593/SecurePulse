export default function About() {
  return (
    <section id="about" className="py-16 px-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <h2 className="text-sm font-semibold text-gray-600 mb-4 tracking-wide uppercase">About Me</h2>
            <h3 className="text-4xl font-bold mb-8 leading-tight text-gray-900">
              DESIGNING IMMACULATE EXPERIENCES
            </h3>
          </div>
          <div className="space-y-6">
            <div>
              <h4 className="font-semibold mb-2 text-gray-900">Building Beyond the Pixels</h4>
              <p className="text-gray-600">Crafting digital experiences that resonate with users while achieving business objectives through thoughtful design decisions.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-gray-900">The Mind Behind the Canvas</h4>
              <p className="text-gray-600">Strategic thinking meets creative execution in every project, ensuring both aesthetic appeal and functional excellence.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-gray-900">Design with Purpose</h4>
              <p className="text-gray-600">Every design choice serves a purpose, from enhancing user experience to driving meaningful engagement and conversion.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}