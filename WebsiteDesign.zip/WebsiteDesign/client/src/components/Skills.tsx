import { Users, Table, PenTool, TrendingUp, Palette, Smartphone, Layers, Zap } from 'lucide-react';
import { SiFigma, SiAdobexd, SiSketch, SiAdobecreativecloud } from 'react-icons/si';

const skillCategories = [
  {
    title: "UX DESIGN",
    skills: [
      { name: "User Research & Testing", icon: Users },
      { name: "Information Architecture", icon: Table },
      { name: "Wireframing & Prototyping", icon: PenTool },
      { name: "Usability Testing", icon: TrendingUp }
    ]
  },
  {
    title: "UI DESIGN",
    skills: [
      { name: "Visual Design & Branding", icon: Palette },
      { name: "Responsive Design", icon: Smartphone },
      { name: "Design Systems", icon: Layers },
      { name: "Interaction Design", icon: Zap }
    ]
  },
  {
    title: "DESIGN TOOLS",
    skills: [
      { name: "Figma", icon: SiFigma },
      { name: "Adobe XD", icon: SiAdobexd },
      { name: "Sketch", icon: SiSketch },
      { name: "Adobe Creative Suite", icon: SiAdobecreativecloud }
    ]
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-16 px-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="mb-12">
          <h2 className="text-sm font-semibold text-gray-600 mb-4 tracking-wide uppercase">Skills</h2>
          <h3 className="text-4xl font-bold mb-6 leading-tight text-gray-900">
            VISUAL PRECISION MEETS PRACTICAL TOOLS
          </h3>
          <p className="text-gray-600 max-w-2xl">
            With a solid grasp of UX principles and an eye for UI aesthetics, I work confidently using the following tools and methodologies to create intuitive experiences.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm">
              <h4 className="font-bold text-xl mb-6 text-gray-900">{category.title}</h4>
              <div className="space-y-3">
                {category.skills.map((skill, skillIndex) => {
                  const IconComponent = skill.icon;
                  return (
                    <div key={skillIndex} className="flex items-center space-x-3">
                      <IconComponent className="w-5 h-5 text-gray-600" />
                      <span className="text-gray-900">{skill.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}