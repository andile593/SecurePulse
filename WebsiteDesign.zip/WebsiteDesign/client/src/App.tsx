import React from 'react';

function App() {
  return React.createElement('div', {
    style: { 
      minHeight: '100vh', 
      backgroundColor: 'white', 
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center' 
    }
  }, React.createElement('h1', {
    style: { 
      fontSize: '2rem', 
      fontWeight: 'bold', 
      color: '#111827' 
    }
  }, 'ANDILE MHLANGA - UI/UX Designer'));
}

export default App;