// Simple development server that just runs Vite
import { createServer } from 'vite';
import path from 'path';

async function startServer() {
  try {
    const server = await createServer({
      root: path.resolve(process.cwd(), 'client'),
      server: {
        host: '0.0.0.0',
        port: 5000,
      },
    });

    await server.listen();
    console.log('Vite development server is running on http://0.0.0.0:5000');
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
}

startServer();