# Portfolio Website - Replit Project Guide

## Overview

This is a modern portfolio website for a UI/UX designer built with a full-stack architecture. The application features a React frontend with TypeScript, an Express.js backend, and uses PostgreSQL with Drizzle ORM for data persistence. The project is designed as a single-page application showcasing design work, skills, and providing a contact form for potential clients.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES Modules
- **API Style**: RESTful API endpoints
- **Middleware**: Express middleware for JSON parsing, logging, and error handling
- **Development**: Hot reload with Vite integration

### Database & ORM
- **Database**: PostgreSQL (configured via Drizzle)
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Connection**: @neondatabase/serverless for database connectivity
- **Schema**: Centralized schema definitions in shared directory

## Key Components

### Frontend Components
1. **Navigation**: Fixed header with smooth scrolling navigation
2. **Hero Section**: Introduction with profile image
3. **About Section**: Personal background and design philosophy
4. **Projects Section**: Portfolio showcase with project cards
5. **Skills Section**: Categorized skill display (UX Design, UI Design, Tools)
6. **Contact Form**: Form with validation and API integration
7. **Footer**: Simple footer with legal links

### Backend Components
1. **Routes**: Contact form submission and retrieval endpoints
2. **Storage**: Abstract storage interface with in-memory implementation
3. **Validation**: Zod schemas for data validation
4. **Error Handling**: Centralized error handling middleware

### UI Component System
- **Design System**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Theme**: Neutral color scheme with dark mode support
- **Icons**: Lucide React icons and React Icons

## Data Flow

### Contact Form Submission
1. User fills out contact form (name, email, message)
2. Form validation occurs client-side using Zod schema
3. Valid data is sent to `/api/contact` endpoint via POST request
4. Server validates data again using shared Zod schema
5. Data is stored using the storage interface
6. Success/error response is sent back and displayed via toast notification

### Data Storage Pattern
- **Interface-based**: IStorage interface allows switching between storage implementations
- **Current Implementation**: In-memory storage with Map data structures
- **Future-ready**: Designed to easily switch to database storage

## External Dependencies

### Core Dependencies
- **Frontend**: React, TypeScript, Tailwind CSS, Wouter, TanStack Query
- **Backend**: Express.js, TypeScript, Drizzle ORM
- **UI Components**: Radix UI primitives, shadcn/ui components
- **Validation**: Zod for schema validation
- **Database**: PostgreSQL via @neondatabase/serverless

### Development Dependencies
- **Build Tools**: Vite, esbuild for production builds
- **Development**: tsx for TypeScript execution
- **Replit Integration**: Vite plugins for Replit environment

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: esbuild bundles server code to `dist/index.js`
3. **Combined Deployment**: Single server serves both API and static files

### Environment Configuration
- **Development**: Uses Vite dev server with proxy for API routes
- **Production**: Express serves static files and API routes
- **Database**: Requires `DATABASE_URL` environment variable

### Replit-Specific Features
- **Development Banner**: Replit development environment integration
- **Error Overlay**: Runtime error modal for development
- **Cartographer**: Code exploration tool integration

### Scripts
- `dev`: Development server with hot reload
- `build`: Production build for both frontend and backend
- `start`: Production server startup
- `db:push`: Database schema push using Drizzle Kit

## Architecture Decisions

### Monorepo Structure
**Problem**: Managing frontend, backend, and shared code
**Solution**: Organized as monorepo with client/, server/, and shared/ directories
**Benefits**: Code sharing, simplified deployment, consistent tooling

### Storage Abstraction
**Problem**: Need flexibility between development and production storage
**Solution**: Interface-based storage pattern with pluggable implementations
**Benefits**: Easy testing, flexible deployment options

### Shared Schema Validation
**Problem**: Ensuring data consistency between frontend and backend
**Solution**: Shared Zod schemas in /shared directory
**Benefits**: Single source of truth, type safety, reduced duplication

### Component-First Design
**Problem**: Maintainable and reusable UI components
**Solution**: shadcn/ui component system with Tailwind CSS
**Benefits**: Consistent design, accessibility, developer experience